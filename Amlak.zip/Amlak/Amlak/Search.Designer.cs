﻿namespace Amlak
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnMain = new System.Windows.Forms.Button();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbSearchMob = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbSearchClient = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbSearchMakler = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cmbSearchRoom = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbSearchDistrict = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbSearchCity = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbSearchRequest = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cmbSearchCondition = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.cmbSearchType = new System.Windows.Forms.ComboBox();
            this.dgvSearch = new System.Windows.Forms.DataGridView();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(514, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(403, 39);
            this.label4.TabIndex = 7;
            this.label4.Text = "EURO STYLE AGENCY";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(739, 668);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(142, 41);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnMain
            // 
            this.btnMain.Location = new System.Drawing.Point(546, 668);
            this.btnMain.Name = "btnMain";
            this.btnMain.Size = new System.Drawing.Size(142, 41);
            this.btnMain.TabIndex = 12;
            this.btnMain.Text = "MAIN";
            this.btnMain.UseVisualStyleBackColor = true;
            this.btnMain.Click += new System.EventHandler(this.btnMain_Click);
            // 
            // btnShowAll
            // 
            this.btnShowAll.Location = new System.Drawing.Point(951, 208);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(91, 49);
            this.btnShowAll.TabIndex = 11;
            this.btnShowAll.Text = "SHOW ALL";
            this.btnShowAll.UseVisualStyleBackColor = true;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(682, 226);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(32, 13);
            this.label28.TabIndex = 89;
            this.label28.Text = "Mobil";
            // 
            // cmbSearchMob
            // 
            this.cmbSearchMob.FormattingEnabled = true;
            this.cmbSearchMob.Location = new System.Drawing.Point(739, 223);
            this.cmbSearchMob.Name = "cmbSearchMob";
            this.cmbSearchMob.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchMob.Sorted = true;
            this.cmbSearchMob.TabIndex = 9;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(682, 192);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(33, 13);
            this.label26.TabIndex = 85;
            this.label26.Text = "Client";
            // 
            // cmbSearchClient
            // 
            this.cmbSearchClient.FormattingEnabled = true;
            this.cmbSearchClient.Location = new System.Drawing.Point(739, 189);
            this.cmbSearchClient.Name = "cmbSearchClient";
            this.cmbSearchClient.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchClient.Sorted = true;
            this.cmbSearchClient.TabIndex = 8;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(682, 156);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 13);
            this.label25.TabIndex = 81;
            this.label25.Text = "Makler";
            // 
            // cmbSearchMakler
            // 
            this.cmbSearchMakler.FormattingEnabled = true;
            this.cmbSearchMakler.Location = new System.Drawing.Point(739, 153);
            this.cmbSearchMakler.Name = "cmbSearchMakler";
            this.cmbSearchMakler.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchMakler.Sorted = true;
            this.cmbSearchMakler.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(495, 226);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 13);
            this.label23.TabIndex = 79;
            this.label23.Text = "Room";
            // 
            // cmbSearchRoom
            // 
            this.cmbSearchRoom.FormattingEnabled = true;
            this.cmbSearchRoom.Location = new System.Drawing.Point(552, 223);
            this.cmbSearchRoom.Name = "cmbSearchRoom";
            this.cmbSearchRoom.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchRoom.Sorted = true;
            this.cmbSearchRoom.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(495, 192);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(39, 13);
            this.label22.TabIndex = 77;
            this.label22.Text = "District";
            // 
            // cmbSearchDistrict
            // 
            this.cmbSearchDistrict.FormattingEnabled = true;
            this.cmbSearchDistrict.Location = new System.Drawing.Point(552, 189);
            this.cmbSearchDistrict.Name = "cmbSearchDistrict";
            this.cmbSearchDistrict.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchDistrict.Sorted = true;
            this.cmbSearchDistrict.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(495, 156);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(24, 13);
            this.label21.TabIndex = 75;
            this.label21.Text = "City";
            // 
            // cmbSearchCity
            // 
            this.cmbSearchCity.FormattingEnabled = true;
            this.cmbSearchCity.Location = new System.Drawing.Point(552, 153);
            this.cmbSearchCity.Name = "cmbSearchCity";
            this.cmbSearchCity.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchCity.Sorted = true;
            this.cmbSearchCity.TabIndex = 4;
            this.cmbSearchCity.SelectedIndexChanged += new System.EventHandler(this.cmbSearchCity_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(294, 226);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 73;
            this.label20.Text = "Request";
            // 
            // cmbSearchRequest
            // 
            this.cmbSearchRequest.FormattingEnabled = true;
            this.cmbSearchRequest.Items.AddRange(new object[] {
            "Kirayə",
            "Satılır"});
            this.cmbSearchRequest.Location = new System.Drawing.Point(351, 223);
            this.cmbSearchRequest.Name = "cmbSearchRequest";
            this.cmbSearchRequest.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchRequest.Sorted = true;
            this.cmbSearchRequest.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(294, 189);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 13);
            this.label19.TabIndex = 71;
            this.label19.Text = "Condition";
            // 
            // cmbSearchCondition
            // 
            this.cmbSearchCondition.FormattingEnabled = true;
            this.cmbSearchCondition.Items.AddRange(new object[] {
            "Köhnə",
            "Yeni"});
            this.cmbSearchCondition.Location = new System.Drawing.Point(351, 186);
            this.cmbSearchCondition.Name = "cmbSearchCondition";
            this.cmbSearchCondition.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchCondition.Sorted = true;
            this.cmbSearchCondition.TabIndex = 2;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(951, 153);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(91, 49);
            this.btnSearch.TabIndex = 10;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(300, 153);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 13);
            this.label18.TabIndex = 68;
            this.label18.Text = "Type";
            // 
            // cmbSearchType
            // 
            this.cmbSearchType.FormattingEnabled = true;
            this.cmbSearchType.Location = new System.Drawing.Point(351, 153);
            this.cmbSearchType.Name = "cmbSearchType";
            this.cmbSearchType.Size = new System.Drawing.Size(121, 21);
            this.cmbSearchType.Sorted = true;
            this.cmbSearchType.TabIndex = 1;
            // 
            // dgvSearch
            // 
            this.dgvSearch.AllowUserToAddRows = false;
            this.dgvSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column13,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17});
            this.dgvSearch.Location = new System.Drawing.Point(99, 273);
            this.dgvSearch.Name = "dgvSearch";
            this.dgvSearch.ReadOnly = true;
            this.dgvSearch.Size = new System.Drawing.Size(1234, 372);
            this.dgvSearch.TabIndex = 91;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Id";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Visible = false;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Type";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 60;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Condition";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 60;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Request";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 60;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "City";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "District";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Price";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Room";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 50;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Note";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Makler";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Status";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 60;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Date Add";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Date Sold";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Client";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Client-Mob";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Buyer";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Visible = false;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Buyer-Mob";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Visible = false;
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkKhaki;
            this.ClientSize = new System.Drawing.Size(1536, 745);
            this.Controls.Add(this.dgvSearch);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.cmbSearchMob);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.cmbSearchClient);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.cmbSearchMakler);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.cmbSearchRoom);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmbSearchDistrict);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.cmbSearchCity);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.cmbSearchRequest);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.cmbSearchCondition);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cmbSearchType);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnMain);
            this.Controls.Add(this.label4);
            this.MaximizeBox = false;
            this.Name = "Search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Search_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnMain;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox cmbSearchMob;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbSearchClient;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbSearchMakler;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cmbSearchRoom;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbSearchDistrict;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbSearchCity;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbSearchRequest;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbSearchCondition;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cmbSearchType;
        private System.Windows.Forms.DataGridView dgvSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
    }
}